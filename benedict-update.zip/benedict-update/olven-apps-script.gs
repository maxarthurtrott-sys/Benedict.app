/* OLVEN backend — paste into script.google.com (NOT into GitHub).
   Runs inside your own Google account: reads Vinted notification emails,
   keeps a small list of items, and serves it to Benedict's Olven tab. */

const CONFIG = {
  SENDER: "vinted",       // matches any sender containing "vinted"
  SHIP_DAYS: 5,           // days you have to ship after a sale (check your Vinted market)
  STALE_DAYS: 30,         // listings older than this get a "repost" nudge
  FIRST_SCAN_DAYS: 120,   // how far back the very first run looks
  NTFY_TOPIC: "",         // optional: long random topic for phone alerts (https://ntfy.sh)
};

// First matching rule wins. Tested against subject + start of the email text.
// These are STARTING GUESSES (English/Czech/German/French) — tune them with ?action=debug.
const RULES = [
  ["sold",    /sold|prodán|prodal|verkauft|vendu/i],
  ["shipped", /shipped|handed over|odesl|versandt|expédi/i],
  ["like",    /favou?rite|likes? your|líbí|oblíben|gefällt|ajouté/i],
  ["listed",  /uploaded|now live|is live|published|nahrán|zveřejněn|veröffentlicht|publié/i],
];

const P = PropertiesService.getScriptProperties();
const DAY = 864e5;

/* Run this ONCE from the editor (select "setup" > Run). */
function setup() {
  if (!P.getProperty("KEY")) P.setProperty("KEY", Utilities.getUuid().replace(/-/g, ""));
  ScriptApp.getProjectTriggers().forEach((t) => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger("sync").timeBased().everyMinutes(30).create();
  ScriptApp.newTrigger("dailyCheck").timeBased().atHour(8).everyDays(1).create();
  sync();
  Logger.log("YOUR KEY: " + P.getProperty("KEY"));
}

/* State is stored in small chunks (a property holds max ~9 KB). */
function loadState() {
  const n = +P.getProperty("S_N") || 0;
  let s = "";
  for (let i = 0; i < n; i++) s += P.getProperty("S_" + i);
  return s ? JSON.parse(s) : { items: {}, seen: [], last: 0, unmatched: [] };
}
function saveState(st) {
  const parts = JSON.stringify(st).match(/[\s\S]{1,3000}/g) || [];
  const old = +P.getProperty("S_N") || 0;
  parts.forEach((x, i) => P.setProperty("S_" + i, x));
  for (let i = parts.length; i < old; i++) P.deleteProperty("S_" + i);
  P.setProperty("S_N", String(parts.length));
}

function sync() {
  const st = loadState();
  const since = st.last ? Math.floor(st.last / 1000) - 300 : Math.floor(Date.now() / 1000) - CONFIG.FIRST_SCAN_DAYS * 86400;
  const t0 = Date.now(), msgs = [];
  for (let start = 0; start < 500 && Date.now() - t0 < 240000; start += 100) {
    const threads = GmailApp.search("from:" + CONFIG.SENDER + " after:" + since, start, 100);
    threads.forEach((t) => t.getMessages().forEach((m) => { if (st.seen.indexOf(m.getId()) < 0) msgs.push(m); }));
    if (threads.length < 100) break;
  }
  msgs.sort((a, b) => a.getDate() - b.getDate());
  msgs.forEach((m) => { apply(st, m); st.seen.push(m.getId()); st.last = Math.max(st.last, m.getDate().getTime()); });
  st.seen = st.seen.slice(-600);
  st.synced = Date.now();
  saveState(st);
  return st;
}

function apply(st, m) {
  const subj = m.getSubject() || "", html = m.getBody() || "", plain = m.getPlainBody() || "";
  const rule = RULES.find((r) => r[1].test(subj + "\n" + plain.slice(0, 600)));
  const link = html.match(/\/items\/(\d+)(?:-([\w-]+))?/);
  if (!rule || !link) {            // keep a few subjects (no bodies) so rules can be tuned
    st.unmatched = (st.unmatched || []).concat([subj.slice(0, 80)]).slice(-30);
    return;
  }
  const id = link[1], when = m.getDate().toISOString();
  const it = st.items[id] || (st.items[id] = { id: id, title: (link[2] || "item " + id).replace(/-/g, " "), listedAt: when, likes: 0 });
  const type = rule[0];
  if (type === "listed") { it.listedAt = when; it.soldAt = null; it.shippedAt = null; }
  if (type === "like" && !it.soldAt) it.likes++;
  if (type === "shipped") it.shippedAt = when;
  if (type === "sold") {
    it.soldAt = when;
    const p = plain.match(/(\d[\d\s.,]*)\s?(Kč|CZK|€|EUR|£|GBP|zł|PLN|\$|USD)/);
    if (p) {
      let n = p[1].replace(/\s/g, "");
      n = n.indexOf(",") > -1 && n.indexOf(".") > -1 ? n.replace(/\./g, "").replace(",", ".") : n.replace(",", ".");
      it.price = parseFloat(n) || 0; it.cur = p[2];
    }
  }
}

/* Benedict calls this. Only answers if the key matches. */
function doGet(e) {
  const p = (e && e.parameter) || {};
  const out = (o) => ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
  if (!p.key || p.key !== P.getProperty("KEY")) return out({ error: "bad key" });
  let st = loadState();
  if (!st.synced || Date.now() - st.synced > 15 * 60000) st = sync();
  if (p.action === "debug") return out({ unmatched: st.unmatched || [], items: Object.keys(st.items).length });
  return out({ updated: new Date(st.synced).toISOString(), shipDays: CONFIG.SHIP_DAYS, staleDays: CONFIG.STALE_DAYS, items: Object.values(st.items) });
}

/* Daily 08:00 (script time zone) phone nudge via ntfy. */
function dailyCheck() {
  const st = sync(), now = Date.now(), lines = [];
  Object.values(st.items).forEach((i) => {
    if (i.soldAt && !i.shippedAt) {
      const left = Date.parse(i.soldAt) + CONFIG.SHIP_DAYS * DAY - now;
      if (left > -5 * DAY) lines.push("Ship: " + i.title.slice(0, 40) + (left < 0 ? " (OVERDUE)" : " (" + Math.ceil(left / DAY) + "d left)"));
    } else if (!i.soldAt && now - Date.parse(i.listedAt) >= CONFIG.STALE_DAYS * DAY && (!i.nagged || now - i.nagged > 14 * DAY)) {
      lines.push("Repost: " + i.title.slice(0, 40)); i.nagged = now;
    }
  });
  saveState(st);
  if (lines.length && CONFIG.NTFY_TOPIC) {
    UrlFetchApp.fetch("https://ntfy.sh/" + CONFIG.NTFY_TOPIC, { method: "post", payload: lines.join("\n"), headers: { Title: "Olven" } });
  }
}
