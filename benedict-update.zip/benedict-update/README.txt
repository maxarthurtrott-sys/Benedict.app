BENEDICT UPDATE - what is in this folder
=========================================

A) GitHub - upload these 4 files, replacing the old ones:
   olven.js (new) - app.js - index.html - service-worker.js
   Then open the app once. From now on updates appear by themselves: no more
   clearing cache or saving the app again. Always open the SAME web address,
   because saved data belongs to that address.
   Settings now has Export / Import backup. Export one before big changes.

B) Olven backend (Google, NOT GitHub) - olven-apps-script.gs
   1. Go to script.google.com > New project. Delete the sample code and paste
      the whole olven-apps-script.gs file.
   2. Project Settings (gear) > set your time zone.
   3. Pick "setup" in the toolbar > Run. Allow access (Google shows
      "unverified app": Advanced > Go to project). It only reads Gmail
      messages from senders containing "vinted".
   4. Open the Execution log and copy YOUR KEY.
   5. Deploy > New deployment > type Web app > Execute as: Me >
      Who has access: Anyone > Deploy. Copy the Web app URL.
   6. Benedict > Olven tab > paste URL and key > Connect.
   7. Check matching: open  URL?key=YOURKEY&action=debug  in a browser. It lists
      Vinted email subjects the rules did not understand. Send those lines
      (subjects only) to Claude to tune the rules.
   Optional: set NTFY_TOPIC (long random text) in the script for a daily nudge.
   After editing the script: Deploy > Manage deployments > edit > New version.
